﻿Imports System.Net

Module HollyHug_WebAppHostService

    Sub wsResult(ByVal result As IAsyncResult)
        Dim listener As HttpListener = result.AsyncState()
        Console.WriteLine("Processing on fakeThread(TM)...")
        Dim context As HttpListenerContext = listener.GetContext()
        Dim request As HttpListenerRequest = context.Request()
        Dim response As HttpListenerResponse = context.Response()
        Dim cramKeys As String = request.QueryString("keys")
        Dim cramFunc As String = LCase(request.QueryString("func"))
        If cramFunc = "are_home" Then
            Dim responseString As String = "YEP:If you can read this, you know where you are!"
            Dim buffer() As Byte = System.Text.Encoding.UTF8.GetBytes(responseString)
            Dim output As System.IO.Stream = response.OutputStream
            response.ContentLength64 = buffer.Length
            output.Write(buffer, 0, buffer.Length)
            output.Close()
        ElseIf cramFunc = "dipwads" Then
            Dim responseString As String = "HEY:Same to you, buddy!"
            Dim buffer() As Byte = System.Text.Encoding.UTF8.GetBytes(responseString)
            Dim output As System.IO.Stream = response.OutputStream
            response.ContentLength64 = buffer.Length
            output.Write(buffer, 0, buffer.Length)
            output.Close()
        Else
            Dim responseString As String = "ERR:Unknown functionality."
            Dim buffer() As Byte = System.Text.Encoding.UTF8.GetBytes(responseString)
            Dim output As System.IO.Stream = response.OutputStream
            response.ContentLength64 = buffer.Length
            output.Write(buffer, 0, buffer.Length)
            output.Close()
        End If
        'listener.Stop()
    End Sub

    Sub Main()
        Dim result As IAsyncResult
        'If Not HttpListener.IsSupported Then
        'Console.WriteLine("Windows XP SP2 or Server 2003 is required to use the HttpListener class.")
        'Exit Sub
        'End If
        'While True
        Dim toThread As AsyncCallback = New AsyncCallback(AddressOf wsResult)
        Dim listener As HttpListener = New HttpListener()
        listener.Prefixes.Add("http://localhost:52074/")
        listener.Start()
        result = listener.BeginGetContext(toThread, listener)
        result.AsyncWaitHandle.WaitOne()
        listener.Close()
        'Console.WriteLine("Listening...")
        'Dim context As HttpListenerContext = listener.GetContext
        'Dim request As HttpListenerRequest = context.Request
        'Dim response As HttpListenerResponse = context.Response
        'Dim cramKeys As String = request.QueryString("keys")
        'Dim cramFunc As String = LCase(request.QueryString("func"))
        'If cramFunc = "are_home" Then
        '    Dim responseString As String = "YEP:If you can read this, you know where you are!"
        '    Dim buffer() As Byte = System.Text.Encoding.UTF8.GetBytes(responseString)
        '    Dim output As System.IO.Stream = response.OutputStream
        '    response.ContentLength64 = buffer.Length
        '    output.Write(buffer, 0, buffer.Length)
        '    output.Close()
        'ElseIf cramFunc = "dipwads" Then
        '    Dim responseString As String = "HEY:Same to you, buddy!"
        '    Dim buffer() As Byte = System.Text.Encoding.UTF8.GetBytes(responseString)
        '    Dim output As System.IO.Stream = response.OutputStream
        '    response.ContentLength64 = buffer.Length
        '    output.Write(buffer, 0, buffer.Length)
        '    output.Close()
        'Else
        '    Dim responseString As String = "ERR:Unknown functionality."
        '    Dim buffer() As Byte = System.Text.Encoding.UTF8.GetBytes(responseString)
        '    Dim output As System.IO.Stream = response.OutputStream
        '    response.ContentLength64 = buffer.Length
        '    output.Write(buffer, 0, buffer.Length)
        '    output.Close()
        'End If
        'listener.Stop()
        'End While
    End Sub

End Module
