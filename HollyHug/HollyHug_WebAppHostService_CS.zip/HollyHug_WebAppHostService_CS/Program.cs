﻿using System;
using System.Diagnostics;
using System.Net;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class HollyHug_WebAppHostService
{
    /// <summary>
    /// Handles the Click event of the button1 control.
    /// </summary>
    /// <param name="sender">The source of the event.</param>
    /// <param name="e">The <see cref="System.Windows.RoutedEventArgs"/> instance containing the event data.</param>
    private static void Main()
    {
        // Create a localhost address with a random port
        string listenerAddress = "http://localhost:8080/";

        // Setup the httplistener class
        HttpListener listener = new HttpListener();
        listener.Prefixes.Add(listenerAddress);
        listener.Start();

        // Set our callback method
        IAsyncResult asyncResult = listener.BeginGetContext(new AsyncCallback(HttpListener_Callback), listener);

        // Wait for an event
        asyncResult.AsyncWaitHandle.WaitOne();

        // Put the application in a loop to wait for the async process to *really* finish processing
        DateTime timeout = DateTime.Now.AddMinutes(2);
        while (!asyncResult.IsCompleted)
        {
            if (DateTime.Now > timeout)
                return;
        }

    }

    protected static void HttpListener_Callback(IAsyncResult result)
    {
        HttpListener listener = (HttpListener)result.AsyncState;

        // Call EndGetContext to complete the asynchronous operation.
        HttpListenerContext context = listener.EndGetContext(result);
        HttpListenerRequest request = context.Request;
        string token = request.QueryString["oauth_token"];
        string verifier = request.QueryString["oauth_verifier"];

        // Obtain a response object.
        HttpListenerResponse response = context.Response;

        string responseString = "<HTML><BODY>You have been authenticated. Please return to the application. <script language=\"javascript\">window.close();</script></BODY></HTML>";
        byte[] buffer = System.Text.Encoding.UTF8.GetBytes(responseString);

        response.ContentLength64 = buffer.Length;
        System.IO.Stream output = response.OutputStream;
        output.Write(buffer, 0, buffer.Length);
        output.Close();

        response.Close();

        listener.Close();

    }
}
